<form role="search" action="<?php echo site_url('/'); ?>" method="get" id="searchform">
    <input type="text" name="s" id="s" placeholder="Sök" />
    <input type="hidden" name="post_type" value="post" />
    <input type="submit" alt="Search" value="" />
</form>